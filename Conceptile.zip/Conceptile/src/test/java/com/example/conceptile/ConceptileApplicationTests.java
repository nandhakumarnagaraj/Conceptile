package com.example.conceptile;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConceptileApplicationTests {

	@Test
	void contextLoads() {
	}

}
