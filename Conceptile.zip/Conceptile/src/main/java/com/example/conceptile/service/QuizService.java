package com.example.conceptile.service;

import java.util.List;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.conceptile.entity.Question;
import com.example.conceptile.entity.User;
import com.example.conceptile.repositories.QuestionRepository;
import com.example.conceptile.repositories.UserRepository;

@Service
public class QuizService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private QuestionRepository questionRepository;

    public User getUserPerformance(Long userId) {
        return userRepository.findById(userId).orElseThrow(() -> new RuntimeException("User not found"));
    }

    public Question getRandomQuestion() {
        List<Question> questions = questionRepository.findAll();
        if (questions.isEmpty()) throw new RuntimeException("No questions available");
        return questions.get(new Random().nextInt(questions.size()));
    }

    public boolean submitAnswer(Long userId, Long questionId, String selectedAnswer) {
        User user = userRepository.findById(userId).orElseThrow(() -> new RuntimeException("User not found"));
        Question question = questionRepository.findById(questionId).orElseThrow(() -> new RuntimeException("Question not found"));

        user.setQuestionsAttempted(user.getQuestionsAttempted() + 1);
        boolean isCorrect = question.getCorrectAnswer().equalsIgnoreCase(selectedAnswer);

        if (isCorrect) user.setCorrectAnswers(user.getCorrectAnswers() + 1);

        user.setScorePercentage((double) user.getCorrectAnswers() / user.getQuestionsAttempted() * 100);
        userRepository.save(user);

        return isCorrect;
    }

    public User endQuiz(Long userId) {
        return userRepository.findById(userId).orElseThrow(() -> new RuntimeException("User not found"));
    }
}
