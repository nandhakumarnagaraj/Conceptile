package com.example.conceptile.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.conceptile.entity.Question;
import com.example.conceptile.entity.User;
import com.example.conceptile.service.QuizService;

@RestController
@RequestMapping("/quiz")
public class QuizController {

    @Autowired
    private QuizService quizService;

    @GetMapping("/dashboard/{userId}")
    public User getDashboard(@PathVariable Long userId) {
        return quizService.getUserPerformance(userId);
    }

    @PostMapping("/take/{userId}")
    public Question takeQuiz(@PathVariable Long userId) {
        // Assume user exists in the system, else handle creation elsewhere.
        return quizService.getRandomQuestion();
    }

    @PostMapping("/submit/{userId}")
    public String submitAnswer(@PathVariable Long userId,
                               @RequestParam Long questionId,
                               @RequestParam String selectedAnswer) {
        boolean isCorrect = quizService.submitAnswer(userId, questionId, selectedAnswer);
        return isCorrect ? "Correct" : "Incorrect";
    }

    @PostMapping("/end/{userId}")
    public User endQuiz(@PathVariable Long userId) {
        return quizService.endQuiz(userId);
    }
}
