package com.example.conceptile.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.conceptile.entity.User;

public interface UserRepository extends JpaRepository<User, Long> {
}
